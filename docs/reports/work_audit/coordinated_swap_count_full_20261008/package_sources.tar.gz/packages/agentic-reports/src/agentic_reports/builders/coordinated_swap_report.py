"""Presentation of the optimistic swap study, separate from its measurements."""

from statistics import median
import shlex

SCHEMA = "agentic_work_audit.coordinated_swap.summary.v1"
HEADERS = ("Trial / mode", "Whole workload (s)", "Due to first token mean (ms)",
           "Due to first token p95 (ms)", "Total TTFT (s)", "Total due delay (s)",
           "Submission waiting total (s)", "Alignment padding total (s)",
           "Loads", "Ready on time / late", "Minimum GPU prefix reuse")


def table_rows(summary):
    return [(f"{a['trial']} / {a['mode']}", f"{a['workload_ms'] / 1000:.3f}",
             f"{a['mean_due_to_first_token_ms']:.1f}", f"{a['p95_due_to_first_token_ms']:.1f}",
             f"{a['total_ttft_ms'] / 1000:.3f}", f"{a['total_due_to_first_token_ms'] / 1000:.3f}",
             f"{a['total_submission_delay_ms'] / 1000:.3f}", f"{a['total_alignment_padding_ms'] / 1000:.3f}",
             str(a['measured_load_count']), f"{a['restores_before_due']} / {a['restores_after_due']}",
             f"{100 * a['minimum_gpu_prefix_fraction']:.1f}%" if a['minimum_gpu_prefix_fraction'] is not None else "unavailable")
            for a in summary.get("arms", [])]


def setup(summary):
    config = summary.get("configuration") or next((a["config"] for a in summary.get("arms", [])), {})
    return (f"20 separate sessions; 4 groups of 5; {config.get('turns', '?')} tool rounds; "
            "1,000 ms waits; paired AB/CD rotation; restricted GPU/8 GiB host KV; "
            f"{config.get('initial_tokens', 8192)} initial prompt words and "
            f"{config.get('tool_words', 16)} new tool words per round; "
            f"GPU token caps {config.get('restricted_gpu_tokens', 110592)} restricted / "
            f"{config.get('resident_gpu_tokens', 262144)} resident; "
            f"{config.get('decode_tokens', 32)} output tokens per replay; "
            f"native {config.get('io_backend', 'direct')} KV transfer; "
            f"{config.get('restore_style', 'serial')} restore submission; "
            f"{config.get('control_style', 'individual')} control calls; "
            f"{config.get('trace_profile', 'kv_lifecycle_lean')} tracing; "
            "no storage; CUDA graphs and overlap scheduling on.")


def finding(summary):
    if summary.get("status") != "complete":
        return "Evidence incomplete; no performance conclusion. " + "; ".join(summary.get("issues", [])[:2])
    pieces = []
    for reference in ("independent", "resident"):
        values = [c["workload_change_pct"] for c in summary.get("comparisons", []) if c["reference"] == reference]
        if values:
            value = median(values)
            pieces.append(f"Coordinated workload was {abs(value):.1f}% {'shorter' if value < 0 else 'longer'} "
                          f"than {reference} (median paired change).")
    late = sum(a["restores_after_due"] for a in summary.get("arms", []) if a["mode"] == "coordinated")
    pieces.append(f"{late} restores were observed ready after their tool deadline.")
    return " ".join(pieces)


def reproduction(summary):
    config = summary.get("configuration") or next((a["config"] for a in summary.get("arms", [])), {})
    modes = list(dict.fromkeys(a["mode"] for a in summary.get("arms", [])))
    trials = sorted({a["trial"] for a in summary.get("arms", [])})
    values = {"SWAP_RUN_ID": summary.get("run_id", "coordinated_swap") + "_repeat",
              "SWAP_TURNS": config.get("turns", 40), "SWAP_DECODE_TOKENS": config.get("decode_tokens", 32),
              "SWAP_INITIAL_TOKENS": config.get("initial_tokens", 8192),
              "SWAP_GPU_TOKENS": config.get("restricted_gpu_tokens", 110592),
              "SWAP_RESIDENT_TOKENS": config.get("resident_gpu_tokens", 262144),
              "SWAP_TOOL_WORDS": config.get("tool_words", 16),
              "SWAP_IO_BACKEND": config.get("io_backend", "direct"),
              "SWAP_RESTORE_STYLE": config.get("restore_style", "serial"),
              "SWAP_CONTROL_STYLE": config.get("control_style", "individual"),
              "SWAP_TRACE_PROFILE": config.get("trace_profile", "kv_lifecycle_lean"),
              "SWAP_TRIALS": " ".join(map(str, trials or [1])),
              "SWAP_MODES": " ".join(modes or ["independent", "coordinated", "resident"])}
    return " \\\n".join(f"{k}={shlex.quote(str(v))}" for k, v in values.items()) + " \\\nbash infra/container/run_work_audit_coordinated_swap.sh"
