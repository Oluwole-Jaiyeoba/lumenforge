#!/usr/bin/env bash
set -euo pipefail

MODEL="${1:-Qwen/Qwen2.5-Coder-7B-Instruct}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIRECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PROJECT_ROOT="$(cd "${DIRECT_ROOT}/.." && pwd)"
cd "${DIRECT_ROOT}"

HARDWARE_PROFILE="${HARDWARE_PROFILE:-nvidia_a10g_24gb}"
HARDWARE_PROFILE_PATH="${HARDWARE_PROFILE_PATH:-}"

load_hardware_profile() {
  if [[ -z "${HARDWARE_PROFILE}" || "${HARDWARE_PROFILE}" == "none" ]]; then
    return
  fi
  local profile_path="${HARDWARE_PROFILE_PATH}"
  if [[ -z "${profile_path}" ]]; then
    profile_path="configs/hardware/${HARDWARE_PROFILE}.env"
  fi
  if [[ ! -f "${profile_path}" ]]; then
    echo "Hardware profile not found: ${profile_path}" >&2
    echo "Set HARDWARE_PROFILE=none or HARDWARE_PROFILE_PATH=<file> to override." >&2
    exit 2
  fi
  # shellcheck disable=SC1090
  source "${profile_path}"
  HARDWARE_PROFILE_PATH="${profile_path}"
}

load_hardware_profile

export HARDWARE_PROFILE
export HARDWARE_PROFILE_PATH

HOST_URL="${HOST_URL:-http://127.0.0.1:30000}"
GATEWAY_URL="${GATEWAY_URL:-http://127.0.0.1:31080}"
REPORT_LABEL="${REPORT_LABEL:-harness_deadline_pressure_$(date +%Y%m%d_%H%M%S)}"
RESULTS_ROOT="${RESULTS_ROOT:-artifacts/results}"
RUN_ROOT="${RUN_ROOT:-${RESULTS_ROOT}/runs/controlled/${REPORT_LABEL}}"
REPORT_DIR="${REPORT_DIR:-${RESULTS_ROOT}/reports/${REPORT_LABEL}}"
UPDATE_LATEST="${UPDATE_LATEST:-1}"
HARNESSES="${HARNESSES:-hatcher codex claude_code opencode qwen_code nemo_agent_toolkit deepseek_harness pi_agent_harness openclaw hermes_agent}"
MODES="${MODES:-no_prefetch controller_ready_time_gpu_backfill}"
for mode in ${MODES}; do
  case "${mode}" in
    pre_harness_priority_hints|e2e_priority_hints|e2e_priority_hints_speculative_prefill)
      echo "Legacy priority-injection mode '${mode}' is unavailable in the active experiment runner." >&2
      exit 2
      ;;
  esac
done
PRESSURE_LEVELS="${PRESSURE_LEVELS:-p0_control p3_high p5_boss_queue}"
MAX_TIMELINE_GAPS="${MAX_TIMELINE_GAPS:-96}"
REPORT_BUILDER_MODE="${REPORT_BUILDER_MODE:-auto}"
SKIP_EXISTING_CASES="${SKIP_EXISTING_CASES:-0}"
SKIP_REPORT_BUILD="${SKIP_REPORT_BUILD:-0}"
PYTHON_BIN="${PYTHON_BIN:-python}"
SERVER_READY_TIMEOUT_SECS="${SERVER_READY_TIMEOUT_SECS:-900}"
MAX_TOTAL_TOKENS="${MAX_TOTAL_TOKENS:-12288}"
HICACHE_SIZE_GB="${HICACHE_SIZE_GB:-8}"
HICACHE_IO_BACKEND="${HICACHE_IO_BACKEND:-direct}"
HICACHE_MEM_LAYOUT="${HICACHE_MEM_LAYOUT:-layer_first}"
HICACHE_STORAGE_BACKEND="${HICACHE_STORAGE_BACKEND:-}"
HICACHE_STORAGE_PREFETCH_POLICY="${HICACHE_STORAGE_PREFETCH_POLICY:-timeout}"
HICACHE_STORAGE_BACKEND_EXTRA_CONFIG="${HICACHE_STORAGE_BACKEND_EXTRA_CONFIG:-}"
HICACHE_STORAGE_PATH="${HICACHE_STORAGE_PATH:-}"
MEM_FRACTION_STATIC="${MEM_FRACTION_STATIC:-0.72}"
BASE_EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS:---disable-cuda-graph --disable-piecewise-cuda-graph --disable-overlap-schedule}"
TRACE_PROFILE="${TRACE_PROFILE:-full_debug}"
if ! command -v "${PYTHON_BIN}" >/dev/null 2>&1; then
  PYTHON_BIN=python3
fi
profile_pythonpath="${PYTHONPATH:-}"
for source_dir in "${PROJECT_ROOT}"/packages/*/src; do
  [[ -d "${source_dir}" ]] || continue
  profile_pythonpath="${source_dir}:${profile_pythonpath}"
done
profile_values="$(PYTHONPATH="${profile_pythonpath}" \
  "${PYTHON_BIN}" -m agentic_backends.sglang.instrumentation_profiles "${TRACE_PROFILE}" --shell)"
while IFS='=' read -r name value; do
  [[ -z "${name}" ]] && continue
  if [[ "${name}" == *_DEFAULT ]]; then
    printf -v "${name}" '%s' "${value}"
  else
    printf -v "${name}" '%s' "${!name:-${value}}"
  fi
done <<< "${profile_values}"
AGENTIC_RUNTIME_TELEMETRY_BACKEND="${AGENTIC_RUNTIME_TELEMETRY_BACKEND:-sglang}"
AGENTIC_KV_COPY_TELEMETRY_ENABLE="${AGENTIC_KV_COPY_TELEMETRY_ENABLE:-1}"
GPU_UTIL_SAMPLE_INTERVAL_MS="${GPU_UTIL_SAMPLE_INTERVAL_MS:-100}"
TRACE_CONTROLLER_DECISIONS="${TRACE_CONTROLLER_DECISIONS:-${TRACE_CONTROLLER_DECISIONS_DEFAULT}}"
TRACE_CONTROLLER_COMPLETION_LINKAGE="${TRACE_CONTROLLER_COMPLETION_LINKAGE:-0}"
TRACE_IDLE_GAP_AUDIT="${TRACE_IDLE_GAP_AUDIT:-${TRACE_IDLE_GAP_AUDIT_DEFAULT}}"
TRACE_REPLAY_FRICTION_DEEP_DIVE="${TRACE_REPLAY_FRICTION_DEEP_DIVE:-0}"
TRACE_REPLAY_BLOCKERS="${TRACE_REPLAY_BLOCKERS:-0}"
TRACE_REPLAY_BLOCKERS_MAX_IDS="${TRACE_REPLAY_BLOCKERS_MAX_IDS:-16}"
TRACE_REPLAY_BLOCKERS_EVENTS="${TRACE_REPLAY_BLOCKERS_EVENTS:-before_acquire,submit}"
FILLER_REPLAY_DEADLINES="${FILLER_REPLAY_DEADLINES:-0}"
FILLER_REPLAY_DEADLINE_MS="${FILLER_REPLAY_DEADLINE_MS:-}"
FILLER_BACKLOG_MODE="${FILLER_BACKLOG_MODE:-once}"
FILLER_BACKLOG_TARGET="${FILLER_BACKLOG_TARGET:-0}"
FILLER_BACKLOG_TOTAL="${FILLER_BACKLOG_TOTAL:-0}"
TOOL_WAIT_PROFILE="${TOOL_WAIT_PROFILE:-fixed}"
TOOL_WAIT_PROFILE_SPEC="${TOOL_WAIT_PROFILE_SPEC:-}"
TOOL_WAIT_SEED="${TOOL_WAIT_SEED:-42}"
TASK_REPLAY_STEPS="${TASK_REPLAY_STEPS:-1}"
AGENTIC_WORKLOAD_PROFILE="${AGENTIC_WORKLOAD_PROFILE:-synthetic_pressure}"
CONTROLLER_CHUNKED_PREFILL_SIZE="${CONTROLLER_CHUNKED_PREFILL_SIZE:-512}"
CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS="${CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS:-4096}"
CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS="${CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS:-}"
CONTROLLER_ADMISSION_AGGRESSIVENESS="${CONTROLLER_ADMISSION_AGGRESSIVENESS:-hard}"
CONTROLLER_CALIBRATED_DEFAULT_FLOOR_MS="${CONTROLLER_CALIBRATED_DEFAULT_FLOOR_MS:-}"
CONTROLLER_CALIBRATED_UNKNOWN_FLOOR_MS="${CONTROLLER_CALIBRATED_UNKNOWN_FLOOR_MS:-}"
CONTROLLER_CALIBRATED_MIN_SAMPLES="${CONTROLLER_CALIBRATED_MIN_SAMPLES:-}"
CONTROLLER_CALIBRATED_QUANTILE="${CONTROLLER_CALIBRATED_QUANTILE:-}"
CONTROLLER_CALIBRATION_HISTORY_CSV="${CONTROLLER_CALIBRATION_HISTORY_CSV:-}"
CONTROLLER_ORACLE_RUNTIME_TRUTH_CSV="${CONTROLLER_ORACLE_RUNTIME_TRUTH_CSV:-}"
CONTROLLER_ORACLE_EXACT_SAFETY_MARGIN_MS="${CONTROLLER_ORACLE_EXACT_SAFETY_MARGIN_MS:-}"
CONTROLLER_ORACLE_EXACT_MAX_IN_FLIGHT="${CONTROLLER_ORACLE_EXACT_MAX_IN_FLIGHT:-}"
CONTROLLER_ORACLE_EXACT_IDLE_OVERRIDE="${CONTROLLER_ORACLE_EXACT_IDLE_OVERRIDE:-}"
CONTROLLER_ORACLE_EXACT_FALLBACK_MS="${CONTROLLER_ORACLE_EXACT_FALLBACK_MS:-}"
WORKLOAD_SHAPE_MODE_INDEPENDENT="${WORKLOAD_SHAPE_MODE_INDEPENDENT:-0}"
CONTROLLER_SHORTHAND_CODEC_CONFIG="${CONTROLLER_SHORTHAND_CODEC_CONFIG:-configs/prompt_codecs/agent_trace_relations_v1.json}"
CONTROLLER_SHORTHAND_ENCODING_SCOPE="${CONTROLLER_SHORTHAND_ENCODING_SCOPE:-target_requests}"
CONTROLLER_VALUE_AWARE_RADIX_EVICTION_POLICY="${CONTROLLER_VALUE_AWARE_RADIX_EVICTION_POLICY:-priority}"
CONTROLLER_REPLAY_ADMISSION_GUARD="${CONTROLLER_REPLAY_ADMISSION_GUARD:-1}"
CONTROLLER_REPLAY_LOOKAHEAD_MS="${CONTROLLER_REPLAY_LOOKAHEAD_MS:-5000}"
CONTROLLER_REPLAY_SAFETY_MARGIN_MS="${CONTROLLER_REPLAY_SAFETY_MARGIN_MS:-500}"
CONTROLLER_MAX_HOLD_MS="${CONTROLLER_MAX_HOLD_MS:-10000}"
CONTROLLER_ALLOW_SMALL_WORK_TOKENS="${CONTROLLER_ALLOW_SMALL_WORK_TOKENS:-256}"
CONTROLLER_GPU_TELEMETRY_POLL_MS="${CONTROLLER_GPU_TELEMETRY_POLL_MS:-250}"
CONTROLLER_GPU_IDLE_UTIL_THRESHOLD_PCT="${CONTROLLER_GPU_IDLE_UTIL_THRESHOLD_PCT:-5}"
CONTROLLER_GPU_IDLE_RECENT_WINDOW_MS="${CONTROLLER_GPU_IDLE_RECENT_WINDOW_MS:-500}"
CONTROLLER_GPU_BACKFILL_MAX_RUNTIME_MS="${CONTROLLER_GPU_BACKFILL_MAX_RUNTIME_MS:-1000}"
CONTROLLER_INSTRUMENTATION_GATE="${CONTROLLER_INSTRUMENTATION_GATE:-auto}"
CONTROLLER_INSTRUMENTATION_POLICY="${CONTROLLER_INSTRUMENTATION_POLICY:-strict}"
CONTROLLER_INSTRUMENTATION_CONTRACT="${CONTROLLER_INSTRUMENTATION_CONTRACT:-${PROJECT_ROOT}/configs/controller_instrumentation_contracts/controller_replay_v1.json}"
CONTROLLER_INSTRUMENTATION_TIMEOUT_SECS="${CONTROLLER_INSTRUMENTATION_TIMEOUT_SECS:-30}"
# The first scheduler batch can follow a fresh backend start by more than the
# gateway round trip. Keep enough room to observe its in-process evidence.
CONTROLLER_INSTRUMENTATION_TRACE_WAIT_SECS="${CONTROLLER_INSTRUMENTATION_TRACE_WAIT_SECS:-30}"

if ! command -v "${PYTHON_BIN}" >/dev/null 2>&1; then
  PYTHON_BIN="python3"
fi
if [[ "${CONTROLLER_INSTRUMENTATION_CONTRACT}" != /* ]]; then
  CONTROLLER_INSTRUMENTATION_CONTRACT="${PROJECT_ROOT}/${CONTROLLER_INSTRUMENTATION_CONTRACT}"
fi
if [[ "${CONTROLLER_INSTRUMENTATION_POLICY}" == "observe_only" ]]; then
  # Diagnostic evidence is never eligible to replace a milestone or latest run.
  UPDATE_LATEST=0
fi
export PYTHON_BIN
export PYTHONPATH="${DIRECT_ROOT}/src:${PYTHONPATH:-}"
export CONTROLLER_REPLAY_ADMISSION_GUARD CONTROLLER_REPLAY_LOOKAHEAD_MS CONTROLLER_REPLAY_SAFETY_MARGIN_MS
export CONTROLLER_MAX_HOLD_MS CONTROLLER_ALLOW_SMALL_WORK_TOKENS
export CONTROLLER_GPU_TELEMETRY_POLL_MS CONTROLLER_GPU_IDLE_UTIL_THRESHOLD_PCT
export CONTROLLER_GPU_IDLE_RECENT_WINDOW_MS CONTROLLER_GPU_BACKFILL_MAX_RUNTIME_MS

controller_mode_requested() {
  local candidate
  for candidate in ${MODES}; do
    if [[ "${candidate}" == controller_* ]]; then
      return 0
    fi
  done
  return 1
}

instrumentation_gate_enabled() {
  case "${CONTROLLER_INSTRUMENTATION_GATE}" in
    on) return 0 ;;
    off) return 1 ;;
    auto) controller_mode_requested ;;
    *) echo "Invalid CONTROLLER_INSTRUMENTATION_GATE=${CONTROLLER_INSTRUMENTATION_GATE}; use auto, on, or off." >&2; exit 2 ;;
  esac
}

run_instrumentation_preflight() {
  local contract="$1"
  local installation_report="$2"
  local live_report="$3"
  local gateway_trace_path="$4"
  local backend_trace_path="$5"
  local copied_contract="$6"
  local package_path=""
  local package_src
  for package_src in "${PROJECT_ROOT}"/packages/*/src; do
    [[ -d "${package_src}" ]] || continue
    package_path="${package_path:+${package_path}:}${package_src}"
  done
  cp "${contract}" "${copied_contract}"
  PYTHONPATH="${package_path}:${DIRECT_ROOT}/src:${PYTHONPATH:-}" \
    "${PYTHON_BIN}" -m agentic_backends.sglang.instrumentation_preflight \
      --stage live \
      --contract "${copied_contract}" \
      --installation-report "${installation_report}" \
      --gateway-base "${GATEWAY_URL}" \
      --model "${MODEL}" \
      --gateway-trace "${gateway_trace_path}" \
      --backend-trace "${backend_trace_path}" \
      --sentinel-trace "${CONTROLLER_INSTRUMENTATION_SENTINEL_TRACE}" \
      --controller-probe-report "${CONTROLLER_INSTRUMENTATION_CONTROLLER_PROBE}" \
      --controller-mode "${mode:-controller_scheduler_priority}" \
      --shared-profile controller_queue \
      --timeout "${CONTROLLER_INSTRUMENTATION_TIMEOUT_SECS}" \
      --trace-wait "${CONTROLLER_INSTRUMENTATION_TRACE_WAIT_SECS}" \
      --policy "${CONTROLLER_INSTRUMENTATION_POLICY}" \
      --out "${live_report}"
}

write_blocked_preflight_report() {
  local case_id="$1"
  local preflight_report="$2"
  REPORT_DIR="${REPORT_DIR}" CASE_ID="${case_id}" PREFLIGHT_REPORT="${preflight_report}" AGENTIC_RUN_MANIFEST="${AGENTIC_RUN_MANIFEST:-}" "${PYTHON_BIN}" - <<'PY'
import html
import json
import os
from pathlib import Path

report_dir = Path(os.environ["REPORT_DIR"])
evidence = Path(os.environ["PREFLIGHT_REPORT"])
payload = json.loads(evidence.read_text(encoding="utf-8")) if evidence.exists() else {"checks": []}
failed = [item.get("id", "unknown") for item in payload.get("checks", []) if item.get("required", True) and not item.get("passed", False)]
manifest = {"status": "blocked_preflight", "invalid_for_controller_claims": True, "case": os.environ["CASE_ID"], "blocking_checks": failed, "preflight": str(evidence)}
for name in ("instrumentation_preflight_summary.json", "blocked_preflight_manifest.json"):
    (report_dir / name).write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
raw_manifest = os.environ.get("AGENTIC_RUN_MANIFEST", "")
run_manifest = Path(raw_manifest) if raw_manifest else None
if run_manifest and run_manifest.exists():
    current = json.loads(run_manifest.read_text(encoding="utf-8"))
    current.update(manifest)
    run_manifest.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n", encoding="utf-8")
reasons = "".join(f"<li>{html.escape(reason)}</li>" for reason in failed) or "<li>Live sentinel request did not produce the required evidence.</li>"
(report_dir / "master_report.html").write_text(f'''<!doctype html><meta charset="utf-8"><title>Experiment Blocked</title><style>body{{font-family:system-ui;margin:40px;max-width:900px}}section{{border:2px solid #b91c1c;padding:24px;border-radius:8px;background:#fff7f7}}</style><section><h1>Experiment validity: BLOCKED</h1><p>Controller-performance charts were not generated. Required instrumentation did not pass live validation.</p><h2>Blocking checks</h2><ul>{reasons}</ul><p>Evidence: <code>{html.escape(str(evidence))}</code></p></section>''', encoding="utf-8")
PY
}

RESULTS_ROOT="$(mkdir -p "${RESULTS_ROOT}" && cd "${RESULTS_ROOT}" && pwd)"
RUN_ROOT="$(mkdir -p "${RUN_ROOT}" && cd "${RUN_ROOT}" && pwd)"
REPORT_DIR="$(mkdir -p "${REPORT_DIR}" && cd "${REPORT_DIR}" && pwd)"
RUN_CONFIG_ENV="${REPORT_DIR}/run_config.env"
RUN_ENV_JSON="${REPORT_DIR}/run_environment.json"
GPU_UTIL_CSV="${REPORT_DIR}/gpu_utilization_samples.csv"
GPU_UTIL_LOG="${REPORT_DIR}/gpu_utilization_sampler.log"
# Snapshot explicit global encoding configuration so a concurrent edit cannot alter a live run.
EXPLICIT_CASE_KEY="${ENCODING_CASE_KEY:-}"
ENCODING_CASE_KEY="${EXPLICIT_CASE_KEY}"
if [[ -n "${PROMPT_CODEC_CONFIG:-}" ]]; then
  cp "${PROMPT_CODEC_CONFIG}" "${REPORT_DIR}/prompt_codec.input.json"
  export PROMPT_CODEC_CONFIG="${REPORT_DIR}/prompt_codec.input.json"
  PROMPT_ENCODING_CASE_KEY="$("${PYTHON_BIN}" - <<'PYCODEC'
import hashlib, json, os, subprocess
from pathlib import Path
config = json.loads(Path(os.environ["PROMPT_CODEC_CONFIG"]).read_text())
workload = os.environ.get("PROMPT_WORKLOAD_JSONL", "")
value = {"config": config, "scope": os.environ.get("PROMPT_ENCODING_SCOPE", "target_requests"),
         "repetition": os.environ.get("PROMPT_REPETITION", "0"),
         "workload": hashlib.sha256(Path(workload).read_bytes()).hexdigest() if workload else "synthetic",
         "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()}
print(hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()[:16])
PYCODEC
)"
  if [[ -n "${ENCODING_CASE_KEY}" ]]; then
    ENCODING_CASE_KEY="${ENCODING_CASE_KEY}_${PROMPT_ENCODING_CASE_KEY}"
  else
    ENCODING_CASE_KEY="${PROMPT_ENCODING_CASE_KEY}"
  fi
fi
GPU_UTIL_SAMPLER_PID=""
SERVER_PID=""
GATEWAY_PID=""

cleanup_case() {
  if [[ -n "${GATEWAY_PID}" ]]; then
    kill "${GATEWAY_PID}" >/dev/null 2>&1 || true
    wait "${GATEWAY_PID}" >/dev/null 2>&1 || true
    GATEWAY_PID=""
  fi
  if [[ -n "${SERVER_PID}" ]]; then
    # ``setsid`` gives the backend its own process group. The ``--`` is
    # essential: without it, Bash parses a negative PID as a signal option
    # and a blocked preflight can leave the Docker backend running.
    kill -- "-${SERVER_PID}" >/dev/null 2>&1 || true
    sleep 2
    kill -9 -- "-${SERVER_PID}" >/dev/null 2>&1 || true
    wait "${SERVER_PID}" >/dev/null 2>&1 || true
    SERVER_PID=""
    # A new case must not mistake the old backend for its own server. Docker
    # can take a moment to release the host-network port after its process
    # group exits, so wait for that release before another launch begins.
    for _ in $(seq 1 30); do
      if ! curl -fsS "${HOST_URL}/health" >/dev/null 2>&1; then
        break
      fi
      sleep 1
    done
    if curl -fsS "${HOST_URL}/health" >/dev/null 2>&1; then
      echo "Backend endpoint stayed live after cleanup: ${HOST_URL}" >&2
      return 1
    fi
  fi
}

stop_gpu_util_sampler() {
  if [[ -n "${GPU_UTIL_SAMPLER_PID}" ]]; then
    kill "${GPU_UTIL_SAMPLER_PID}" >/dev/null 2>&1 || true
    wait "${GPU_UTIL_SAMPLER_PID}" >/dev/null 2>&1 || true
    GPU_UTIL_SAMPLER_PID=""
  fi
}
trap 'cleanup_case; stop_gpu_util_sampler' EXIT

start_gpu_util_sampler() {
  if [[ "${AGENTIC_KV_GPU_UTIL_SAMPLER}" != "1" ]]; then
    return
  fi
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    echo "GPU util sampler disabled: nvidia-smi not found."
    return
  fi
  "${PYTHON_BIN}" scripts/sample_gpu_utilization.py \
    --out "${GPU_UTIL_CSV}" \
    --interval-ms "${GPU_UTIL_SAMPLE_INTERVAL_MS}" >"${GPU_UTIL_LOG}" 2>&1 &
  GPU_UTIL_SAMPLER_PID="$!"
}

wait_for_server() {
  local log="$1"
  local ready=0
  for _ in $(seq 1 "${SERVER_READY_TIMEOUT_SECS}"); do
    if curl -fsS "${HOST_URL}/model_info" >/dev/null 2>&1; then
      ready=1
      break
    fi
    if [[ -n "${SERVER_PID}" ]] && ! kill -0 "${SERVER_PID}" >/dev/null 2>&1; then
      echo "SGLang exited before becoming ready. Log tail:"
      tail -160 "${log}" || true
      exit 1
    fi
    sleep 1
  done
  if [[ "${ready}" != "1" ]]; then
    echo "SGLang did not become ready. Log tail:"
    tail -160 "${log}" || true
    exit 1
  fi
  if instrumentation_gate_enabled; then
    # The metadata endpoint can answer before the first model forward completes.
    ready=0
    for _ in $(seq 1 4); do
      if curl -fsS --max-time 30 -H 'Content-Type: application/json' \
        -d '{"text":"Reply: ready.","sampling_params":{"max_new_tokens":1,"temperature":0}}' \
        "${HOST_URL}/generate" >/dev/null 2>&1; then
        ready=1
        break
      fi
      sleep 2
    done
    if [[ "${ready}" != "1" ]]; then
      echo "SGLang answered model_info but did not complete an inference readiness probe. Log tail:" >&2
      tail -160 "${log}" >&2 || true
      exit 1
    fi
  fi
}

wait_for_gateway() {
  for _ in $(seq 1 60); do
    if curl -fsS "${GATEWAY_URL}/health" >/dev/null 2>&1; then
      return
    fi
    sleep 1
  done
  echo "Harness gateway did not become ready." >&2
  exit 1
}

level_knobs() {
  local profile_value=""
  case "$1" in
    p0_control)
      profile_value="${P0_CONTROL_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=500 target_prompt_tokens=1024 filler_sessions=0 filler_prompt_tokens=768 session_count=1 concurrency=1"
      ;;
    p1_mild)
      profile_value="${P1_MILD_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=250 target_prompt_tokens=2048 filler_sessions=8 filler_prompt_tokens=1024 session_count=1 concurrency=4"
      ;;
    p2_medium)
      profile_value="${P2_MEDIUM_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=100 target_prompt_tokens=3072 filler_sessions=16 filler_prompt_tokens=1536 session_count=1 concurrency=6"
      ;;
    p3_high)
      profile_value="${P3_HIGH_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=50 target_prompt_tokens=4096 filler_sessions=32 filler_prompt_tokens=1536 session_count=1 concurrency=8"
      ;;
    p4_cliff)
      profile_value="${P4_CLIFF_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=25 target_prompt_tokens=4096 filler_sessions=48 filler_prompt_tokens=2048 session_count=1 concurrency=10"
      ;;
    p5_boss_queue)
      profile_value="${P5_BOSS_QUEUE_KNOBS:-}"
      if [[ -n "${profile_value}" ]]; then echo "${profile_value}"; return; fi
      echo "tool_wait_ms=50 target_prompt_tokens=4096 filler_sessions=4 filler_prompt_tokens=2048 session_count=4 concurrency=12"
      ;;
    *)
      echo "Unknown pressure level: $1" >&2
      exit 2
      ;;
  esac
}

write_run_config() {
  {
    echo "REPORT_LABEL=${REPORT_LABEL}"
    echo "MODEL=${MODEL}"
    echo "EXPERIMENT_KIND=multi_harness_deadline_pressure"
    echo "RESULTS_ROOT=${RESULTS_ROOT}"
    echo "RUN_ROOT=${RUN_ROOT}"
    echo "REPORT_DIR=${REPORT_DIR}"
    echo "HARDWARE_PROFILE=${HARDWARE_PROFILE}"
    echo "HARDWARE_PROFILE_PATH=${HARDWARE_PROFILE_PATH}"
    echo "AGENTIC_BACKEND_RUNTIME_CONTRACT=${AGENTIC_BACKEND_RUNTIME_CONTRACT:-}"
    echo "AGENTIC_RUN_MANIFEST=${AGENTIC_RUN_MANIFEST:-}"
    echo "CONTROLLER_INSTRUMENTATION_GATE=${CONTROLLER_INSTRUMENTATION_GATE}"
    echo "CONTROLLER_INSTRUMENTATION_POLICY=${CONTROLLER_INSTRUMENTATION_POLICY}"
    echo "CONTROLLER_INSTRUMENTATION_CONTRACT=${CONTROLLER_INSTRUMENTATION_CONTRACT}"
    echo "HARNESSES=${HARNESSES}"
    echo "MODES=${MODES}"
    echo "AGENTIC_EQUAL_IMPORTANCE_WORKLOAD=${AGENTIC_EQUAL_IMPORTANCE_WORKLOAD:-0}"
    echo "PROMPT_CODEC_CONFIG=${PROMPT_CODEC_CONFIG:-}"
    echo "PROMPT_ENCODING_SCOPE=${PROMPT_ENCODING_SCOPE:-target_requests}"
    echo "PROMPT_WORKLOAD_JSONL=${PROMPT_WORKLOAD_JSONL:-}"
    echo "ENCODING_CASE_KEY=${ENCODING_CASE_KEY}"
    echo "PRESSURE_LEVELS=${PRESSURE_LEVELS}"
    echo "SKIP_EXISTING_CASES=${SKIP_EXISTING_CASES}"
    echo "MAX_TOTAL_TOKENS=${MAX_TOTAL_TOKENS}"
    echo "HICACHE_SIZE_GB=${HICACHE_SIZE_GB}"
    echo "HICACHE_IO_BACKEND=${HICACHE_IO_BACKEND}"
    echo "HICACHE_MEM_LAYOUT=${HICACHE_MEM_LAYOUT}"
    echo "HICACHE_STORAGE_BACKEND=${HICACHE_STORAGE_BACKEND}"
    echo "HICACHE_STORAGE_PREFETCH_POLICY=${HICACHE_STORAGE_PREFETCH_POLICY}"
    echo "HICACHE_STORAGE_BACKEND_EXTRA_CONFIG=${HICACHE_STORAGE_BACKEND_EXTRA_CONFIG}"
    echo "HICACHE_STORAGE_PATH=${HICACHE_STORAGE_PATH}"
    echo "MEM_FRACTION_STATIC=${MEM_FRACTION_STATIC}"
    echo "P0_CONTROL=$(level_knobs p0_control | tr ' ' ',')"
    echo "P1_MILD=$(level_knobs p1_mild | tr ' ' ',')"
    echo "P2_MEDIUM=$(level_knobs p2_medium | tr ' ' ',')"
    echo "P3_QUEUE_PRESSURE=$(level_knobs p3_high | tr ' ' ',')"
    echo "P4_CLIFF=$(level_knobs p4_cliff | tr ' ' ',')"
    echo "P5_BOSS_QUEUE=$(level_knobs p5_boss_queue | tr ' ' ',')"
    echo "FILLER_REPLAY_DEADLINES=${FILLER_REPLAY_DEADLINES}"
    echo "FILLER_REPLAY_DEADLINE_MS=${FILLER_REPLAY_DEADLINE_MS}"
    echo "FILLER_BACKLOG_MODE=${FILLER_BACKLOG_MODE}"
    echo "FILLER_BACKLOG_TARGET=${FILLER_BACKLOG_TARGET}"
    echo "FILLER_BACKLOG_TOTAL=${FILLER_BACKLOG_TOTAL}"
    echo "TOOL_WAIT_PROFILE=${TOOL_WAIT_PROFILE}"
    echo "TOOL_WAIT_PROFILE_SPEC=${TOOL_WAIT_PROFILE_SPEC}"
    echo "TOOL_WAIT_SEED=${TOOL_WAIT_SEED}"
    echo "TASK_REPLAY_STEPS=${TASK_REPLAY_STEPS}"
    echo "AGENTIC_WORKLOAD_PROFILE=${AGENTIC_WORKLOAD_PROFILE}"
    echo "TRACE_PROFILE=${TRACE_PROFILE}"
    echo "TRACE_CONTROLLER_DECISIONS=${TRACE_CONTROLLER_DECISIONS}"
    echo "TRACE_CONTROLLER_COMPLETION_LINKAGE=${TRACE_CONTROLLER_COMPLETION_LINKAGE}"
    echo "TRACE_IDLE_GAP_AUDIT=${TRACE_IDLE_GAP_AUDIT}"
    echo "TRACE_REPLAY_FRICTION_DEEP_DIVE=${TRACE_REPLAY_FRICTION_DEEP_DIVE}"
    echo "TRACE_REPLAY_BLOCKERS=${TRACE_REPLAY_BLOCKERS}"
    echo "TRACE_REPLAY_BLOCKERS_MAX_IDS=${TRACE_REPLAY_BLOCKERS_MAX_IDS}"
    echo "TRACE_REPLAY_BLOCKERS_EVENTS=${TRACE_REPLAY_BLOCKERS_EVENTS}"
    echo "CONTROLLER_REPLAY_ADMISSION_GUARD=${CONTROLLER_REPLAY_ADMISSION_GUARD}"
    echo "CONTROLLER_REPLAY_LOOKAHEAD_MS=${CONTROLLER_REPLAY_LOOKAHEAD_MS}"
    echo "CONTROLLER_REPLAY_SAFETY_MARGIN_MS=${CONTROLLER_REPLAY_SAFETY_MARGIN_MS}"
    echo "CONTROLLER_MAX_HOLD_MS=${CONTROLLER_MAX_HOLD_MS}"
    echo "CONTROLLER_ALLOW_SMALL_WORK_TOKENS=${CONTROLLER_ALLOW_SMALL_WORK_TOKENS}"
    echo "CONTROLLER_GPU_TELEMETRY_POLL_MS=${CONTROLLER_GPU_TELEMETRY_POLL_MS}"
    echo "CONTROLLER_GPU_IDLE_UTIL_THRESHOLD_PCT=${CONTROLLER_GPU_IDLE_UTIL_THRESHOLD_PCT}"
    echo "CONTROLLER_GPU_IDLE_RECENT_WINDOW_MS=${CONTROLLER_GPU_IDLE_RECENT_WINDOW_MS}"
    echo "CONTROLLER_GPU_BACKFILL_MAX_RUNTIME_MS=${CONTROLLER_GPU_BACKFILL_MAX_RUNTIME_MS}"
    echo "AGENTIC_KV_TRACE_SCHEDULER=${AGENTIC_KV_TRACE_SCHEDULER}"
    echo "AGENTIC_KV_TRACE_KV_POOL=${AGENTIC_KV_TRACE_KV_POOL}"
    echo "AGENTIC_KV_COPY_TELEMETRY_ENABLE=${AGENTIC_KV_COPY_TELEMETRY_ENABLE}"
    echo "AGENTIC_RUNTIME_TELEMETRY=${AGENTIC_RUNTIME_TELEMETRY}"
    echo "AGENTIC_KV_GPU_UTIL_SAMPLER=${AGENTIC_KV_GPU_UTIL_SAMPLER}"
    echo "CONTROLLER_CHUNKED_PREFILL_SIZE=${CONTROLLER_CHUNKED_PREFILL_SIZE}"
    echo "CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS=${CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS}"
    echo "CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS=${CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS}"
    echo "CONTROLLER_ADMISSION_AGGRESSIVENESS=${CONTROLLER_ADMISSION_AGGRESSIVENESS}"
    echo "CONTROLLER_CALIBRATED_DEFAULT_FLOOR_MS=${CONTROLLER_CALIBRATED_DEFAULT_FLOOR_MS}"
    echo "CONTROLLER_CALIBRATED_UNKNOWN_FLOOR_MS=${CONTROLLER_CALIBRATED_UNKNOWN_FLOOR_MS}"
    echo "CONTROLLER_CALIBRATED_MIN_SAMPLES=${CONTROLLER_CALIBRATED_MIN_SAMPLES}"
    echo "CONTROLLER_CALIBRATED_QUANTILE=${CONTROLLER_CALIBRATED_QUANTILE}"
    echo "CONTROLLER_CALIBRATION_HISTORY_CSV=${CONTROLLER_CALIBRATION_HISTORY_CSV}"
    echo "CONTROLLER_ORACLE_RUNTIME_TRUTH_CSV=${CONTROLLER_ORACLE_RUNTIME_TRUTH_CSV}"
    echo "CONTROLLER_ORACLE_EXACT_SAFETY_MARGIN_MS=${CONTROLLER_ORACLE_EXACT_SAFETY_MARGIN_MS}"
    echo "CONTROLLER_ORACLE_EXACT_MAX_IN_FLIGHT=${CONTROLLER_ORACLE_EXACT_MAX_IN_FLIGHT}"
    echo "CONTROLLER_ORACLE_EXACT_IDLE_OVERRIDE=${CONTROLLER_ORACLE_EXACT_IDLE_OVERRIDE}"
    echo "CONTROLLER_ORACLE_EXACT_FALLBACK_MS=${CONTROLLER_ORACLE_EXACT_FALLBACK_MS}"
    echo "WORKLOAD_SHAPE_MODE_INDEPENDENT=${WORKLOAD_SHAPE_MODE_INDEPENDENT}"
    echo "CONTROLLER_SHORTHAND_CODEC_CONFIG=${CONTROLLER_SHORTHAND_CODEC_CONFIG}"
    echo "CONTROLLER_SHORTHAND_ENCODING_SCOPE=${CONTROLLER_SHORTHAND_ENCODING_SCOPE}"
  } >"${RUN_CONFIG_ENV}"
}

collect_run_environment() {
  if [[ -f scripts/collect_run_environment.py ]]; then
    "${PYTHON_BIN}" scripts/collect_run_environment.py \
      --out "${RUN_ENV_JSON}" \
      --model "${MODEL}" \
      --run-config-env "${RUN_CONFIG_ENV}" \
      --controlled-root "${RUN_ROOT}" || true
  fi
}

run_case() {
  local harness="$1"
  local mode="$2"
  local level="$3"
  local knobs
  knobs="$(level_knobs "${level}")"
  local tool_wait_ms target_prompt_tokens filler_sessions filler_prompt_tokens session_count concurrency
  eval "${knobs}"
  local case_id="${harness}_${level}_${mode}_tw${tool_wait_ms}_f${filler_sessions}"
  if [[ "${TOOL_WAIT_PROFILE}" != "fixed" || "${TASK_REPLAY_STEPS}" != "1" || -n "${TOOL_WAIT_PROFILE_SPEC}" ]]; then
    local safe_tool_wait_profile
    safe_tool_wait_profile="$(printf '%s' "${TOOL_WAIT_PROFILE}" | tr -c 'A-Za-z0-9_' '_')"
    case_id="${case_id}_twprof${safe_tool_wait_profile}_steps${TASK_REPLAY_STEPS}_seed${TOOL_WAIT_SEED}"
  fi
  if [[ -n "${ENCODING_CASE_KEY}" ]]; then case_id="${case_id}_enc${ENCODING_CASE_KEY}"; fi
  if [[ "${mode}" == "controller_priority_demotion_admission_shorthand" && -z "${PROMPT_CODEC_CONFIG:-}" ]]; then
    case_id="${case_id}_codecshorthand"
  fi
  local case_root="${RUN_ROOT}/${case_id}"
  local trace="${case_root}/m27_trace.jsonl"
  local backend_trace="${case_root}/backend_trace.jsonl"
  local telemetry="${case_root}/m27_copy_telemetry.jsonl"
  local runtime_telemetry="${case_root}/runtime_telemetry.jsonl"
  local metrics="${case_root}/m27_metrics.jsonl"
  local server_log="${case_root}/sglang_server.log"
  local gateway_log="${case_root}/harness_gateway.log"
  local gateway_events="${case_root}/harness_gateway_events.jsonl"
  local case_gpu_util_csv="${case_root}/gpu_utilization_samples.csv"
  local case_gpu_util_log="${case_root}/gpu_utilization_sampler.log"
  local instrumentation_contract_copy="${case_root}/instrumentation_contract.json"
  local hook_installation_report="${case_root}/hook_installation_report.json"
  local live_sentinel_report="${case_root}/live_sentinel_report.json"
  local live_sentinel_trace="${case_root}/live_sentinel_trace.jsonl"
  local controller_probe_report="${case_root}/controller_preflight_probe.jsonl"
  local case_prompt_codec_config="${PROMPT_CODEC_CONFIG:-}"
  local case_prompt_encoding_scope="${PROMPT_ENCODING_SCOPE:-target_requests}"
  local case_hicache_storage_backend=""
  local case_hicache_storage_prefetch_policy=""
  local case_hicache_storage_backend_extra_config=""
  local case_hicache_storage_path=""

  if [[ "${mode}" == "controller_priority_demotion_admission_shorthand" && -z "${case_prompt_codec_config}" ]]; then
    case_prompt_codec_config="${CONTROLLER_SHORTHAND_CODEC_CONFIG}"
    case_prompt_encoding_scope="${CONTROLLER_SHORTHAND_ENCODING_SCOPE}"
  fi

  mkdir -p "${case_root}"
  if [[ "${SKIP_EXISTING_CASES}" == "1" && -s "${metrics}" && -s "${trace}" ]] && grep -q '"event": "m27.workload_end"' "${trace}"; then
    echo
    echo "==== Skipping existing completed case: ${case_id} ===="
    return
  fi
  rm -f "${trace}" "${backend_trace}" "${telemetry}" "${runtime_telemetry}" "${metrics}" "${server_log}" "${gateway_log}" "${gateway_events}" "${case_gpu_util_csv}" "${case_gpu_util_log}" "${instrumentation_contract_copy}" "${hook_installation_report}" "${live_sentinel_report}" "${live_sentinel_trace}" "${controller_probe_report}"
  if [[ "${mode}" == storage_hicache_* ]]; then
    case_hicache_storage_backend="${HICACHE_STORAGE_BACKEND}"
    case_hicache_storage_prefetch_policy="${HICACHE_STORAGE_PREFETCH_POLICY}"
    case_hicache_storage_backend_extra_config="${HICACHE_STORAGE_BACKEND_EXTRA_CONFIG}"
    case_hicache_storage_path="${HICACHE_STORAGE_PATH}"
    if [[ -z "${case_hicache_storage_backend}" ]]; then
      case_hicache_storage_backend="file"
    fi
    if [[ -z "${case_hicache_storage_path}" ]]; then
      case_hicache_storage_path="${case_root}/hicache_storage"
    fi
    mkdir -p "${case_hicache_storage_path}"
  fi
  if [[ -n "${case_prompt_codec_config}" ]]; then
    cp "${case_prompt_codec_config}" "${case_root}/prompt_codec.input.json"
    case_prompt_codec_config="${case_root}/prompt_codec.input.json"
  fi

  echo
  echo "==== Multi-harness case: harness=${harness} mode=${mode} level=${level} ===="
  GPU_UTIL_CSV="${case_gpu_util_csv}"
  GPU_UTIL_LOG="${case_gpu_util_log}"
  start_gpu_util_sampler
  export AGENTIC_KV_TRACE_ENABLE=1
  # The gateway and in-process backend are distinct evidence producers. They
  # must never share a JSONL path: concurrent appends can hide backend hooks.
  export AGENTIC_KV_TRACE_PATH="${backend_trace}"
  export AGENTIC_KV_TRACE_INSTALL_REPORT_PATH="${hook_installation_report}"
  export AGENTIC_KV_TRACE_SCHEDULER
  export AGENTIC_KV_TRACE_KV_POOL
  export TRACE_CONTROLLER_COMPLETION_LINKAGE
  export AGENTIC_KV_COPY_TELEMETRY_ENABLE
  export AGENTIC_KV_COPY_TELEMETRY_PATH="${telemetry}"
  export AGENTIC_RUNTIME_TELEMETRY
  export AGENTIC_RUNTIME_TELEMETRY_BACKEND
  export AGENTIC_RUNTIME_TELEMETRY_PATH="${runtime_telemetry}"
  export HICACHE_SIZE_GB
  export HICACHE_IO_BACKEND
  export HICACHE_MEM_LAYOUT
  export HICACHE_STORAGE_BACKEND="${case_hicache_storage_backend}"
  export HICACHE_STORAGE_PREFETCH_POLICY="${case_hicache_storage_prefetch_policy}"
  export HICACHE_STORAGE_BACKEND_EXTRA_CONFIG="${case_hicache_storage_backend_extra_config}"
  export HICACHE_STORAGE_PATH="${case_hicache_storage_path}"
  export MEM_FRACTION_STATIC
  export EXTRA_SERVER_ARGS="${BASE_EXTRA_SERVER_ARGS} --max-total-tokens ${MAX_TOTAL_TOKENS}"
  if [[ "${mode}" == "e2e_priority_hints" || "${mode}" == "pre_harness_priority_hints" || "${mode}" == "nat_inferred_priority_hints" || "${mode}" == "e2e_priority_hints_speculative_prefill" || "${mode}" == "harness_emitted_signals" || "${mode}" == "controller_scheduler_priority" || "${mode}" == "controller_demote_restore" || "${mode}" == "controller_priority_demote" || "${mode}" == "controller_priority_demotion_admission" || "${mode}" == "controller_priority_demotion_admission_soft" || "${mode}" == "controller_priority_demotion_admission_medium" || "${mode}" == "controller_priority_demotion_admission_hard" || "${mode}" == "controller_priority_demotion_admission_earlyprepare" || "${mode}" == "controller_priority_demotion_admission_shorthand" || "${mode}" == "controller_oracle_timeline" || "${mode}" == "controller_oracle_safe_sjf" || "${mode}" == "controller_oracle_safe_sjf_balanced" || "${mode}" == "controller_oracle_safe_sjf_aggressive" || "${mode}" == "controller_oracle_safe_sjf_maxfill" || "${mode}" == "controller_priority_demotion_calibrated_admission" || "${mode}" == "controller_oracle_exact_runtime_admission" || "${mode}" == "controller_deadline_fair" || "${mode}" == "controller_predictive_deadline_queue" || "${mode}" == "controller_predictive_deadline_queue_admission_guard" || "${mode}" == "controller_ready_time_gpu_backfill" || "${mode}" == "controller_harness_aware_sched" || "${mode}" == "controller_harness_aware_sched_kv" || "${mode}" == "controller_harness_aware_sched_evict" || "${mode}" == "controller_harness_aware_full" || "${mode}" == "controller_memory_admission" || "${mode}" == "controller_admission_control" || "${mode}" == "controller_full" || "${mode}" == "controller_full_chunked_prefill" || "${mode}" == "controller_value_aware_eviction" ]]; then
    export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --enable-cache-report --enable-priority-scheduling --default-priority-value 0 --schedule-policy fcfs"
  elif [[ "${mode}" == "no_cache_signal" || "${mode}" == "harness_native_cache_lowered" || "${mode}" == "controller_speculative_preload" || "${mode}" == "controller_targeted_kv_prefetch" || "${mode}" == "controller_proactive_kv_management" || "${mode}" == "storage_hicache_baseline" || "${mode}" == "storage_hicache_controller_prefetch" ]]; then
    export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --enable-cache-report"
  fi
  if [[ "${mode}" == "controller_value_aware_eviction" || "${mode}" == "controller_harness_aware_sched_evict" || "${mode}" == "controller_harness_aware_full" ]]; then
    if [[ "${mode}" == "controller_value_aware_eviction" && "${CONTROLLER_EVICTION_SIGNAL_POLICY:-}" == "reuse_time" ]]; then
      # Isolate retention: native FCFS must not also sort by the cache rank.
      export EXTRA_SERVER_ARGS="${BASE_EXTRA_SERVER_ARGS} --max-total-tokens ${MAX_TOTAL_TOKENS} --enable-cache-report --schedule-policy fcfs"
    fi
    export AGENTIC_KV_ENABLE_PRIORITY_RADIX_EVICTION_CHOICE="${AGENTIC_KV_ENABLE_PRIORITY_RADIX_EVICTION_CHOICE:-1}"
    export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --radix-eviction-policy ${CONTROLLER_VALUE_AWARE_RADIX_EVICTION_POLICY}"
  fi
  if [[ "${mode}" == "controller_full_chunked_prefill" ]]; then
    export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --chunked-prefill-size ${CONTROLLER_CHUNKED_PREFILL_SIZE}"
    if [[ -n "${CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS}" ]]; then
      export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --max-prefill-tokens ${CONTROLLER_CHUNKED_MAX_PREFILL_TOKENS}"
    fi
    if [[ -n "${CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS}" ]]; then
      export EXTRA_SERVER_ARGS="${EXTRA_SERVER_ARGS} --prefill-max-requests ${CONTROLLER_CHUNKED_PREFILL_MAX_REQUESTS}"
    fi
  fi

  if [[ -n "${ENCODING_CASE_KEY}" ]]; then
    # Never attach to or terminate another experiment's serving processes.
    "${PYTHON_BIN}" - <<'PYPORT'
import socket
for port in (30000, 31080):
    with socket.socket() as sock:
        if sock.connect_ex(("127.0.0.1", port)) == 0:
            raise SystemExit(f"Port {port} is occupied; leave the active experiment running and retry later.")
PYPORT
  fi
  if command -v setsid >/dev/null 2>&1; then
    setsid bash scripts/run_sglang_hicache_server.sh "${MODEL}" >"${server_log}" 2>&1 &
  else
    bash scripts/run_sglang_hicache_server.sh "${MODEL}" >"${server_log}" 2>&1 &
  fi
  SERVER_PID="$!"
  wait_for_server "${server_log}"
  if [[ "${CONTROLLER_AUDIT_PINNED_RUNTIME:-0}" == "1" ]]; then
    "${PYTHON_BIN}" - "${HOST_URL}" "${case_root}/server_info.json" "${mode}" <<'PYRUNTIME'
import json, sys, urllib.request
info = json.load(urllib.request.urlopen(sys.argv[1] + "/get_server_info"))
with open(sys.argv[2], "w") as stream:
    json.dump(info, stream, indent=2)
args = info.get("server_args", info)
for flag in ("disable_cuda_graph", "disable_overlap_schedule"):
    if args.get(flag) is not False:
        raise SystemExit(f"Production runtime gate: {flag} must be false; got {args.get(flag)!r}")
expected = sys.argv[3] == "controller_ready_time_gpu_backfill"
if args.get("enable_priority_scheduling") is not expected:
    raise SystemExit("Queue isolation gate: unexpected priority scheduling setting")
PYRUNTIME
  fi

  "${PYTHON_BIN}" scripts/harness_sglang_gateway.py \
    --listen-host 127.0.0.1 \
    --listen-port 31080 \
    --target-base "${HOST_URL}" \
    --trace "${trace}" \
    --log "${gateway_events}" \
    --model "${MODEL}" \
    --prompt-codec-config "${case_prompt_codec_config}" \
    --encoding-scope "${case_prompt_encoding_scope}" >"${gateway_log}" 2>&1 &
  GATEWAY_PID="$!"
  wait_for_gateway

  if instrumentation_gate_enabled; then
    if [[ ! -f "${CONTROLLER_INSTRUMENTATION_CONTRACT}" ]]; then
      echo "Controller instrumentation contract not found: ${CONTROLLER_INSTRUMENTATION_CONTRACT}" >&2
      exit 2
    fi
    echo "Validating controller instrumentation before workload measurement..."
    if ! CONTROLLER_INSTRUMENTATION_SENTINEL_TRACE="${live_sentinel_trace}" CONTROLLER_INSTRUMENTATION_CONTROLLER_PROBE="${controller_probe_report}" run_instrumentation_preflight "${CONTROLLER_INSTRUMENTATION_CONTRACT}" "${hook_installation_report}" "${live_sentinel_report}" "${trace}" "${backend_trace}" "${instrumentation_contract_copy}"; then
      if [[ "${CONTROLLER_INSTRUMENTATION_POLICY}" == "strict" ]]; then
        write_blocked_preflight_report "${case_id}" "${live_sentinel_report}"
        echo "Controller experiment blocked by instrumentation preflight. Report: ${REPORT_DIR}/master_report.html" >&2
        exit 2
      fi
    fi
  fi

  local driver_extra_args=()
  if [[ "${FILLER_REPLAY_DEADLINES}" == "1" ]]; then
    driver_extra_args+=(--filler-replay-deadlines)
  fi
  if [[ -n "${FILLER_REPLAY_DEADLINE_MS}" ]]; then
    driver_extra_args+=(--filler-replay-deadline-ms "${FILLER_REPLAY_DEADLINE_MS}")
  fi
  if [[ "${mode}" == "nat_inferred_priority_hints" || ( "${mode}" == "harness_emitted_signals" && "${harness}" == "nemo_agent_toolkit" ) ]]; then
    driver_extra_args+=(--nat-inferred-profile-out "${REPORT_DIR}/nat_inferred_priority_profile.json")
  fi

  PYTHONPATH="${DIRECT_ROOT}/src:${PYTHONPATH:-}" "${PYTHON_BIN}" scripts/run_multi_harness_replay_driver.py \
    --harness "${harness}" \
    --mode "${mode}" \
    --pressure-level "${level}" \
    --gateway-base "${GATEWAY_URL}" \
    --model "${MODEL}" \
    --trace "${trace}" \
    --out "${metrics}" \
    --log-dir "${case_root}/harness_logs" \
    --tool-wait-ms "${tool_wait_ms}" \
    --tool-wait-profile "${TOOL_WAIT_PROFILE}" \
    --tool-wait-profile-spec "${TOOL_WAIT_PROFILE_SPEC}" \
    --tool-wait-seed "${TOOL_WAIT_SEED}" \
    --task-replay-steps "${TASK_REPLAY_STEPS}" \
    --agentic-workload-profile "${AGENTIC_WORKLOAD_PROFILE}" \
    --target-prompt-tokens "${target_prompt_tokens}" \
    --filler-sessions "${filler_sessions}" \
    --filler-prompt-tokens "${filler_prompt_tokens}" \
    --filler-backlog-mode "${FILLER_BACKLOG_MODE}" \
    --filler-backlog-target "${FILLER_BACKLOG_TARGET}" \
    --filler-backlog-total "${FILLER_BACKLOG_TOTAL}" \
    --session-count "${session_count}" \
    --concurrency "${concurrency}" \
    --trace-profile "${TRACE_PROFILE}" \
    --trace-controller-decisions "${TRACE_CONTROLLER_DECISIONS}" \
    --trace-controller-completion-linkage "${TRACE_CONTROLLER_COMPLETION_LINKAGE}" \
    --trace-replay-blockers "${TRACE_REPLAY_BLOCKERS}" \
    --trace-replay-blockers-max-ids "${TRACE_REPLAY_BLOCKERS_MAX_IDS}" \
    --trace-replay-blockers-events "${TRACE_REPLAY_BLOCKERS_EVENTS}" \
    "${driver_extra_args[@]}" | tee "${case_root}/driver.log"

  cleanup_case
  stop_gpu_util_sampler
  echo "==== Completed: ${case_id} ===="
}

build_final_report() {
  if [[ "${SKIP_REPORT_BUILD}" == "1" ]]; then
    echo "Skipping report build for this run piece because SKIP_REPORT_BUILD=1."
    return
  fi
  write_run_config
  collect_run_environment
  local harness_count pressure_count mode_count case_count report_builder
  harness_count="$(wc -w <<<"${HARNESSES}")"
  pressure_count="$(wc -w <<<"${PRESSURE_LEVELS}")"
  mode_count="$(wc -w <<<"${MODES}")"
  case_count="$((harness_count * pressure_count * mode_count))"
  report_builder="${REPORT_BUILDER_MODE}"
  if [[ "${report_builder}" == "auto" ]]; then
    if (( case_count > 36 )); then
      report_builder="lightweight"
    else
      report_builder="rich"
    fi
  fi
  if [[ "${report_builder}" == "lightweight" ]]; then
    local latest_args=()
    if [[ "${UPDATE_LATEST}" == "1" ]]; then
      latest_args=(--update-latest)
    fi
    "${PYTHON_BIN}" scripts/build_multi_harness_deadline_summary.py \
      --root "${RUN_ROOT}" \
      --out-dir "${REPORT_DIR}" \
      --latest-root "${RESULTS_ROOT}" \
      --report-label "${REPORT_LABEL}" \
      --run-config "${RUN_CONFIG_ENV}" \
      --run-environment-json "${RUN_ENV_JSON}" \
      "${latest_args[@]}"
    if [[ "${TRACE_REPLAY_FRICTION_DEEP_DIVE}" == "1" ]]; then
      local friction_latest_args=()
      if [[ "${UPDATE_LATEST}" == "1" ]]; then
        friction_latest_args=(--update-latest-root "${RESULTS_ROOT}")
      fi
      "${PYTHON_BIN}" scripts/build_replay_friction_deep_dive.py \
        --report-dir "${REPORT_DIR}" \
        --run-root "${RUN_ROOT}" \
        --report-label "${REPORT_LABEL}" \
        --top-level-copy-dir "${PROJECT_ROOT}/docs/reports" \
        "${friction_latest_args[@]}"
    fi
    return
  fi
  "${PYTHON_BIN}" scripts/build_milestone27_controlled_replay_report.py \
    --root "${RUN_ROOT}" \
    --out-dir "${REPORT_DIR}/report" \
    --latest-root "${RESULTS_ROOT}" \
    --max-timeline-gaps "${MAX_TIMELINE_GAPS}" \
    --run-environment-json "${RUN_ENV_JSON}" \
    --gpu-util-csv "${GPU_UTIL_CSV}"
  cp -f "${REPORT_DIR}/report/controlled_replay_report.html" "${REPORT_DIR}/master_report.html"
  for artifact in controlled_replay_report.json controlled_replay_gaps.csv global_kv_readiness_by_mode.csv global_kv_readiness_by_mode_summary.csv global_replay_start_by_mode_summary.csv replay_delay_gap_verdicts.csv replay_path_ledger.csv instrumentation_coverage.csv request_id_coverage_report.csv exact_kv_movement_attribution.csv exact_kv_movement_summary.csv kv_block_ledger.csv kv_block_ledger.json kv_block_lifecycle_summary.csv kv_block_gap_summary.csv gpu_utilization_samples.csv runtime_telemetry_events.csv request_state_snapshots.csv; do
    if [[ -f "${REPORT_DIR}/report/${artifact}" ]]; then
      cp -f "${REPORT_DIR}/report/${artifact}" "${REPORT_DIR}/${artifact}"
    fi
  done
  if [[ "${TRACE_REPLAY_FRICTION_DEEP_DIVE}" == "1" ]]; then
    local friction_latest_args=()
    if [[ "${UPDATE_LATEST}" == "1" ]]; then
      friction_latest_args=(--update-latest-root "${RESULTS_ROOT}")
    fi
    "${PYTHON_BIN}" scripts/build_replay_friction_deep_dive.py \
      --report-dir "${REPORT_DIR}" \
      --run-root "${RUN_ROOT}" \
      --report-label "${REPORT_LABEL}" \
      --top-level-copy-dir "${PROJECT_ROOT}/docs/reports" \
      "${friction_latest_args[@]}"
  fi
  REPORT_LABEL="${REPORT_LABEL}" MODEL="${MODEL}" RESULTS_ROOT="${RESULTS_ROOT}" RUN_ROOT="${RUN_ROOT}" REPORT_DIR="${REPORT_DIR}" UPDATE_LATEST="${UPDATE_LATEST}" HARDWARE_PROFILE="${HARDWARE_PROFILE}" HARDWARE_PROFILE_PATH="${HARDWARE_PROFILE_PATH}" HARNESSES="${HARNESSES}" MODES="${MODES}" PRESSURE_LEVELS="${PRESSURE_LEVELS}" "${PYTHON_BIN}" - <<'PY'
import json
import os
from datetime import datetime, timezone
from pathlib import Path

report_dir = Path(os.environ["REPORT_DIR"])
results_root = Path(os.environ["RESULTS_ROOT"])
manifest = {
    "report_label": os.environ["REPORT_LABEL"],
    "experiment_kind": "multi_harness_deadline_pressure",
    "model": os.environ["MODEL"],
    "controlled_root": os.environ["RUN_ROOT"],
    "latest_report": str(results_root / "latest_master_report.html"),
    "archived_report": str(report_dir / "master_report.html"),
    "generated_at": datetime.now(timezone.utc).isoformat(),
    "script": "scripts/run_harness_deadline_pressure.sh",
    "hardware_profile": os.environ.get("HARDWARE_PROFILE", ""),
    "hardware_profile_path": os.environ.get("HARDWARE_PROFILE_PATH", ""),
    "harnesses": os.environ.get("HARNESSES", ""),
    "modes": os.environ.get("MODES", ""),
    "pressure_levels": os.environ.get("PRESSURE_LEVELS", ""),
    "chart_title": "Replay Deadline Pressure Chart",
}

(report_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
if os.environ.get("UPDATE_LATEST") == "1":
    (results_root / "latest_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

write_instrumentation_validity_summary() {
  RUN_ROOT="${RUN_ROOT}" REPORT_DIR="${REPORT_DIR}" RESULTS_ROOT="${RESULTS_ROOT}" UPDATE_LATEST="${UPDATE_LATEST}" AGENTIC_RUN_MANIFEST="${AGENTIC_RUN_MANIFEST:-}" "${PYTHON_BIN}" - <<'PY'
import html
import json
import os
from pathlib import Path

run_root = Path(os.environ["RUN_ROOT"])
report_dir = Path(os.environ["REPORT_DIR"])
rows = []
for path in sorted(run_root.glob("*/live_sentinel_report.json")):
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        continue
    rows.append({
        "case": path.parent.name,
        "valid": bool(payload.get("valid")),
        "policy": payload.get("policy", ""),
        "contract": Path(payload.get("contract", "")).name,
        "adapter": payload.get("installation", {}).get("adapter", ""),
        "version": payload.get("installation", {}).get("sglang_version", ""),
        "required_passed": len({check.get("id") for check in payload.get("checks", []) if check.get("required", True) and check.get("passed")}),
        "required_total": len({check.get("id") for check in payload.get("checks", []) if check.get("required", True)}),
        "optional_unavailable": sum(1 for check in payload.get("checks", []) if not check.get("required", True) and not check.get("passed")),
    })
if not rows:
    raise SystemExit(0)
summary = {"schema_version": "agentic_controller_instrumentation_summary.v1", "all_valid": all(row["valid"] for row in rows), "cases": rows}
(report_dir / "instrumentation_preflight_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
raw_manifest = os.environ.get("AGENTIC_RUN_MANIFEST", "")
run_manifest = Path(raw_manifest) if raw_manifest else None
if run_manifest and run_manifest.exists():
    current = json.loads(run_manifest.read_text(encoding="utf-8"))
    current["instrumentation_valid"] = summary["all_valid"]
    current["invalid_for_controller_claims"] = not summary["all_valid"]
    current["instrumentation_preflight_summary"] = str(report_dir / "instrumentation_preflight_summary.json")
    run_manifest.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n", encoding="utf-8")
status = "VALID" if summary["all_valid"] else "INVALID - do not use for controller claims"
color = "#166534" if summary["all_valid"] else "#b91c1c"
table_rows = "".join(
    f"<tr><td>{html.escape(row['case'])}</td><td>{'valid' if row['valid'] else 'invalid'}</td><td>{row['required_passed']} of {row['required_total']}</td><td>{row['optional_unavailable']}</td><td>{html.escape(row['adapter'])} {html.escape(row['version'])}</td><td>{html.escape(row['policy'])}</td></tr>"
    for row in rows
)
panel = f'''<section style="margin:18px 0;padding:16px 20px;border:2px solid {color};border-radius:8px;background:#fff">
<h2 style="margin:0 0 8px">Controller Instrumentation Validity: <span style="color:{color}">{status}</span></h2>
<p style="margin:0 0 10px">Every controller case must install its required hooks and produce live sentinel evidence before workload measurement begins.</p>
<table><thead><tr><th>Case</th><th>Gate</th><th>Required proof</th><th>Optional unavailable</th><th>Runtime</th><th>Policy</th></tr></thead><tbody>{table_rows}</tbody></table>
<p style="margin:10px 0 0"><a href="instrumentation_preflight_summary.json">Open preflight summary</a>.</p></section>'''
for name in ("master_report.html", "evidence_tables.html"):
    path = report_dir / name
    if path.exists():
        text = path.read_text(encoding="utf-8")
        if "Controller Instrumentation Validity:" not in text:
            path.write_text(text.replace("<main>", "<main>\n" + panel, 1), encoding="utf-8")
if os.environ.get("UPDATE_LATEST") == "1":
    latest = Path(os.environ["RESULTS_ROOT"])
    (latest / "instrumentation_preflight_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

echo "Multi-Harness Replay Deadline Pressure"
echo "MODEL=${MODEL}"
echo "REPORT_LABEL=${REPORT_LABEL}"
echo "HARDWARE_PROFILE=${HARDWARE_PROFILE}"
echo "HARDWARE_PROFILE_PATH=${HARDWARE_PROFILE_PATH}"
echo "HARNESSES=${HARNESSES}"
echo "MODES=${MODES}"
echo "PRESSURE_LEVELS=${PRESSURE_LEVELS}"
echo "TOOL_WAIT_PROFILE=${TOOL_WAIT_PROFILE}"
echo "TASK_REPLAY_STEPS=${TASK_REPLAY_STEPS}"
echo "AGENTIC_WORKLOAD_PROFILE=${AGENTIC_WORKLOAD_PROFILE}"
echo "TOOL_WAIT_SEED=${TOOL_WAIT_SEED}"
if [[ -n "${TOOL_WAIT_PROFILE_SPEC}" ]]; then
  echo "TOOL_WAIT_PROFILE_SPEC=${TOOL_WAIT_PROFILE_SPEC}"
fi

for harness in ${HARNESSES}; do
  for level in ${PRESSURE_LEVELS}; do
    for mode in ${MODES}; do
      run_case "${harness}" "${mode}" "${level}"
    done
  done
done
build_final_report
write_instrumentation_validity_summary

echo
echo "Done."
echo "Latest report: ${RESULTS_ROOT}/latest_master_report.html"
echo "Archived labeled report: ${REPORT_DIR}/master_report.html"
