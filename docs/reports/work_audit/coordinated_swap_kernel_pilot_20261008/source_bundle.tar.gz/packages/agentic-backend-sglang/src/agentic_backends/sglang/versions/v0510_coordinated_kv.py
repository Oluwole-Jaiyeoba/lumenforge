"""Scheduler-thread cache inspection/release for the opt-in coordinated audit."""

from __future__ import annotations

from typing import Any


def assert_private_prefix(entry: dict, entries: list[dict]) -> None:
    ids = entry.get("coordinated_token_ids") or []
    identity = (entry.get("request") or {}).get("agent_session_id")
    if len(ids) < 128 or not identity:
        raise ValueError("Missing session identity or private prefix")
    for other in entries:
        if (other.get("request") or {}).get("agent_session_id") == identity:
            continue
        if (other.get("coordinated_token_ids") or [])[:64] == ids[:64]:
            raise ValueError("Prefix anchor is shared by another session")


def release_subtree(cache: Any, anchor: Any) -> dict:
    """Release only an unlocked, durably host-backed private subtree."""
    nodes = []
    stack = [(anchor, False)]
    while stack:
        node, visited = stack.pop()
        if visited:
            if not node.evicted:
                nodes.append(node)
        else:
            stack.append((node, True))
            stack.extend((child, False) for child in node.children.values())
    # Check the entire set before making any mutation.
    for node in nodes:
        if node.lock_ref or node.id in cache.ongoing_load_back:
            return {"ok": False, "status": "prefix_busy", "node_id": str(node.id)}
        if not node.backuped or node.id in cache.ongoing_write_through:
            return {"ok": False, "status": "host_backup_pending", "node_id": str(node.id)}
    count = sum(cache._evict_backuped(node) for node in nodes)
    return {"ok": True, "status": "released", "evicted_tokens": count,
            "evicted_node_ids": [str(node.id) for node in nodes]}


def prefix_control(entry: dict, command: dict) -> dict:
    from importlib.metadata import version
    from sglang.srt.mem_cache.base_prefix_cache import MatchPrefixParams
    from sglang.srt.mem_cache.radix_cache import RadixKey

    cache = entry["tree_cache"]
    if version("sglang") != "0.5.10.post1":
        raise ValueError("Coordinated cache control is validated only for 0.5.10.post1")
    if type(cache).__name__ != "HiRadixCache" or cache.tp_world_size != 1:
        raise ValueError("Coordinated cache control requires single-rank HiRadixCache")
    ids = entry.get("coordinated_token_ids") or []
    if len(ids) < 128:
        raise ValueError("Registered coordinated prefix is missing or too short")
    cache.loading_check()
    cache.writing_check()
    match = cache.match_prefix(MatchPrefixParams(key=RadixKey(ids, entry.get("coordinated_extra_key"))))
    entry["last_host_node"] = match.last_host_node
    entry["last_node"] = match.last_device_node
    nodes = []
    node = match.last_host_node
    while node is not cache.root_node:
        nodes.append(node)
        node = node.parent
    resident = sum(len(n.key) for n in nodes if not n.evicted)
    host = sum(len(n.key) for n in nodes if n.backuped)
    result = {"ok": True, "status": "residency", "cached_tokens": sum(len(n.key) for n in nodes),
              "gpu_tokens": resident, "host_tokens": host,
              "pending_loads": sum(n.id in cache.ongoing_load_back for n in nodes),
              "registered_tokens": len(ids), "gpu_free_tokens": cache.cache_controller.mem_pool_device_allocator.available_size()}
    if command["action"] == "release_prefix":
        # The runner gives every session a different first 64-token prefix.
        # Splitting at that boundary avoids touching common chat/template nodes.
        anchor_match = cache.match_prefix(MatchPrefixParams(
            key=RadixKey(ids[:64], entry.get("coordinated_extra_key"))))
        anchor = anchor_match.last_host_node
        if anchor is cache.root_node or len(anchor.key) == 0:
            raise ValueError("No private prefix anchor")
        result.update(release_subtree(cache, anchor))
    return result
