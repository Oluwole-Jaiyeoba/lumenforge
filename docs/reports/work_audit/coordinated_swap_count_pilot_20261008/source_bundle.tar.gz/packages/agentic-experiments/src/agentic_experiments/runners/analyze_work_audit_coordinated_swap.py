"""Join paired-swap measurements to native replay cache evidence."""

import argparse
import gzip
import json
from pathlib import Path


def first_matches(path: Path) -> dict:
    matches = {}
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("event") != "hiradix.match_prefix.end":
                continue
            ctx = row.get("kv_context") or {}
            req = ctx.get("request") or {}
            rid = ctx.get("agent_request_id") or req.get("agent_request_id")
            result = row.get("result")
            if rid and rid not in matches and isinstance(result, list) and result:
                matches[rid] = {"gpu_tokens": result[0].get("index_count", 0),
                                "host_tokens": result[3] if len(result) > 3 else None}
    return matches


def analyze(root: Path, trials: list[int], modes: list[str]) -> dict:
    arms, issues, cases = [], [], []
    for trial in trials:
        for mode in modes:
            folder = root / "arms" / f"trial{trial}_{mode}"
            path = folder / "case_results.json"
            if not path.exists():
                issues.append(f"Missing {folder.name}")
                continue
            case = json.loads(path.read_text())
            cases.append(case)
            if case["status"] != "complete":
                issues.append(f"{folder.name}: {case.get('error')}")
                continue
            trace = folder / "backend_trace.jsonl.gz"
            if not trace.exists():
                trace = folder / "backend_trace.jsonl"
            matches = first_matches(trace)
            replays = case["turns"]
            if len(replays) != case["config"]["sessions"] * case["config"]["turns"]:
                issues.append(f"{folder.name}: incomplete replay count")
            matched = [matches.get(r["request_id"]) for r in replays]
            if not all(matched):
                issues.append(f"{folder.name}: missing native cache lookup evidence")
            reuse = [m["gpu_tokens"] / r["prompt_tokens"] for r, m in zip(replays, matched) if m]
            if mode in {"coordinated", "resident"} and (not reuse or min(reuse) < .90):
                issues.append(f"{folder.name}: at least one replay reused less than 90% of its prefix on GPU")
            releases = [c for c in case["controls"] if c["action"] == "release_prefix" and c["result"].get("ok")]
            loads = [c for c in case["controls"] if c["action"] in {"prepare", "prepare_group"} and c["result"].get("load_id")]
            measured_loads = [c for c in loads if c["sent_ns"] >= case["started_ns"]]
            readiness = []
            with (folder / "harness_events.jsonl").open() as stream:
                for line in stream:
                    row = json.loads(line)
                    if row.get("event") == "coordinated.restore_ready" and row["slot"] >= 0:
                        readiness.append(row["ready_ns"] <= row["tool_due_ns"])
            arms.append({"trial": trial, "mode": mode, "started_ns": case["started_ns"],
                         "config": case["config"], **case["metrics"],
                         "setup_ms": case["setup_ms"], "minimum_gpu_prefix_fraction": min(reuse) if reuse else None,
                         "native_matches": sum(m is not None for m in matched),
                         "measured_load_count": len(measured_loads),
                         "measured_loaded_tokens": sum(c["result"]["loaded_tokens"] for c in measured_loads),
                         "measured_released_tokens": sum(c["result"]["evicted_tokens"] for c in releases
                                                         if c["sent_ns"] >= case["started_ns"]),
                         "restores_before_due": sum(readiness), "restores_after_due": len(readiness) - sum(readiness),
                         "correctness": case.get("correctness"),
                         "per_session_completion_ms": {
                             session: (max(r["request_end_ns"] for r in replays if r["session_id"] == session)
                                       - case["started_ns"]) / 1e6 for session in sorted({r["session_id"] for r in replays})}})
    comparisons = []
    for trial in trials:
        by_mode = {a["mode"]: a for a in arms if a["trial"] == trial}
        if "coordinated" not in by_mode:
            continue
        for reference in ("independent", "resident"):
            if reference in by_mode:
                a, b = by_mode["coordinated"], by_mode[reference]
                comparisons.append({"trial": trial, "reference": reference,
                                    "workload_change_pct": 100 * (a["workload_ms"] / b["workload_ms"] - 1),
                                    "due_to_first_token_change_ms": a["mean_due_to_first_token_ms"] - b["mean_due_to_first_token_ms"]})
    return {"schema": "agentic_work_audit.coordinated_swap.summary.v1", "run_id": root.name,
            "status": "blocked" if issues else "complete", "issues": issues, "arms": arms,
            "started_ns": min((c.get("started_ns", c["setup_started_ns"]) for c in cases), default=None),
            "configuration": cases[0]["config"] if cases else {}, "comparisons": comparisons,
            "failures": issues,
            "research_question": "Can ideally coordinated independent sessions hide real CPU/GPU KV swaps?",
            "limitations": ["Optimistic paired timeline; not a fair causal comparison of grouping alone.",
                       "Twenty separate synthetic contexts; fixed tool-result text and forced output length.",
                       "Setup excluded and reported separately; measured control, swap and alignment delays included.",
                       "Matched GPU prefix is reuse evidence, not an independent tensor-level proof of every copy.",
                       "No storage, semantic priorities, or shared model context."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--expected-trials", nargs="+", type=int, required=True)
    parser.add_argument("--expected-modes", nargs="+", required=True)
    args = parser.parse_args()
    summary = analyze(args.run_root, args.expected_trials, args.expected_modes)
    (args.run_root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"status": summary["status"], "issues": summary["issues"], "comparisons": summary["comparisons"]}, indent=2))
    if summary["status"] != "complete":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
